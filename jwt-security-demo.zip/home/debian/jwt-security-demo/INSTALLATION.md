# Guía de Instalación - JWT Security Demo

Esta guía te ayudará a ejecutar el proyecto en cualquier equipo con Docker instalado.

## 📋 Prerrequisitos

Antes de comenzar, asegúrate de tener instalado:

1. **Docker Desktop** (Windows/Mac) o **Docker Engine** (Linux)
   - Windows/Mac: [Descargar Docker Desktop](https://www.docker.com/products/docker-desktop)
   - Linux: [Instalar Docker Engine](https://docs.docker.com/engine/install/)

2. **Docker Compose** (generalmente viene incluido con Docker Desktop)

## ✅ Verificar la instalación

Abre una terminal/consola y ejecuta:

```bash
docker --version
docker-compose --version
```

Deberías ver algo como:
```
Docker version 24.x.x
docker-compose version 2.x.x
```

## 📦 Estructura del Proyecto

Asegúrate de tener esta estructura de carpetas:

```
jwt-security-demo/
├── src/
│   └── main/
│       ├── java/
│       │   └── com/example/
│       │       ├── Application.java
│       │       └── security/...
│       └── resources/
│           └── application.yml
├── Dockerfile
├── docker-compose.yml
├── pom.xml
└── README.md
```

## 🚀 Instalación y Ejecución

### Opción 1: Usando Docker Compose (Recomendado)

1. **Abre una terminal** en la carpeta del proyecto

2. **Construye y ejecuta** con un solo comando:

```bash
docker-compose up --build
```

3. **Espera** a que veas este mensaje:
```
JWT Security Demo - Aplicación iniciada
Puerto: 8080
```

4. **Prueba la aplicación** abriendo tu navegador en:
```
http://localhost:8080
```

### Opción 2: Usando comandos Docker directos

1. **Construir la imagen**:

```bash
docker build -t jwt-security-demo .
```

2. **Ejecutar el contenedor**:

```bash
docker run -p 8080:8080 jwt-security-demo
```

## 🛑 Detener la Aplicación

### Si usaste Docker Compose:

```bash
# Detener (presiona Ctrl+C si está en primer plano)
# O si está en segundo plano:
docker-compose down
```

### Si usaste Docker directamente:

```bash
# Listar contenedores
docker ps

# Detener el contenedor
docker stop <container_id>
```

## 🔧 Comandos Útiles

### Ver logs en tiempo real:

```bash
docker-compose logs -f
```

### Ejecutar en segundo plano:

```bash
docker-compose up -d
```

### Ver contenedores activos:

```bash
docker ps
```

### Eliminar todo (contenedores, imágenes, volúmenes):

```bash
docker-compose down -v --rmi all
```

### Reconstruir desde cero:

```bash
docker-compose down
docker-compose build --no-cache
docker-compose up
```

## 🧪 Probar que Funciona

### 1. Usando cURL (Terminal)

```bash
# Hacer login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"admin123"}'
```

Deberías recibir una respuesta con un token JWT:
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "username": "admin",
  "authorities": "..."
}
```

### 2. Usando Postman

1. Crea una nueva petición POST
2. URL: `http://localhost:8080/api/auth/login`
3. Body (JSON):
```json
{
  "username": "admin",
  "password": "admin123"
}
```
4. Envía la petición

### 3. Usando navegador

Visita: `http://localhost:8080/api/public/info`

Deberías ver:
```json
{
  "message": "Este es un endpoint público",
  "note": "No requiere autenticación"
}
```

## 🐛 Solución de Problemas Comunes

### Error: "Puerto 8080 ya está en uso"

**Solución 1**: Liberar el puerto
```bash
# Windows
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:8080 | xargs kill -9
```

**Solución 2**: Cambiar el puerto

Edita `docker-compose.yml`:
```yaml
ports:
  - "8081:8080"  # Cambia 8081 por el puerto que desees
```

### Error: "Cannot connect to Docker daemon"

**Windows/Mac**: Inicia Docker Desktop

**Linux**: 
```bash
sudo systemctl start docker
sudo systemctl enable docker
```

### Error: "permission denied" (Linux)

```bash
# Agregar tu usuario al grupo docker
sudo usermod -aG docker $USER

# Cerrar sesión y volver a iniciar
```

### La aplicación no responde

1. Verifica que el contenedor esté corriendo:
```bash
docker ps
```

2. Ve los logs:
```bash
docker-compose logs
```

3. Verifica que el puerto esté abierto:
```bash
curl http://localhost:8080/api/public/info
```

### Error al compilar (Maven)

Si la compilación falla por problemas de dependencias:

```bash
# Limpiar y reconstruir sin caché
docker-compose build --no-cache
```

## 💡 Consejos para el Trabajo en Equipo

### Compartir el proyecto

1. **Comprimir** toda la carpeta del proyecto
2. **Compartir** el archivo .zip con tu equipo
3. **Descomprimir** en sus máquinas
4. **Ejecutar** `docker-compose up --build`

### Variables de entorno personalizadas

Cada miembro del equipo puede crear un archivo `.env`:

```bash
JWT_SECRET=su_clave_secreta_personal
JWT_EXPIRATION=86400000
```

Y modificar `docker-compose.yml`:
```yaml
env_file:
  - .env
```

### Sincronizar cambios

Si alguien hace cambios al código:

1. **Detener** el contenedor actual
2. **Reconstruir** la imagen: `docker-compose build`
3. **Reiniciar**: `docker-compose up`

## 📱 Probar desde otro dispositivo en la misma red

1. **Encuentra tu IP** en la máquina donde corre Docker:

```bash
# Windows
ipconfig

# Linux/Mac
ifconfig
# o
ip addr show
```

2. **Usa esa IP** desde otro dispositivo:
```
http://192.168.x.x:8080/api/auth/login
```

3. **Nota**: Asegúrate de que el firewall permita conexiones en el puerto 8080

## 🔒 Consideraciones de Seguridad

⚠️ **IMPORTANTE**: Esta aplicación es SOLO para aprendizaje

- NO uses en producción sin cambios de seguridad
- La clave JWT debe ser única y segura
- Los usuarios están hardcodeados (en producción usa base de datos)
- No hay HTTPS configurado (en producción es obligatorio)

## 📞 Soporte

Si tienes problemas:

1. Revisa los logs: `docker-compose logs -f`
2. Verifica que Docker esté corriendo
3. Asegúrate de tener la estructura de carpetas correcta
4. Intenta reconstruir sin caché: `docker-compose build --no-cache`

## ✨ Próximos Pasos

Una vez que la aplicación esté funcionando:

1. Lee el [README.md](README.md) para entender los conceptos
2. Prueba los diferentes endpoints con las credenciales de prueba
3. Experimenta modificando el código
4. Completa las actividades propuestas

¡Feliz aprendizaje! 🎓