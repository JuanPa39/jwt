#!/bin/bash

# Script de configuración para JWT Security Demo

echo "======================================"
echo "JWT Security Demo - Setup"
echo "======================================"

# Verificar si Docker está instalado
if ! command -v docker &> /dev/null; then
    echo "❌ Error: Docker no está instalado"
    echo "Por favor instala Docker desde: https://docs.docker.com/get-docker/"
    exit 1
fi

# Verificar si Docker Compose está instalado
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Error: Docker Compose no está instalado"
    echo "Por favor instala Docker Compose desde: https://docs.docker.com/compose/install/"
    exit 1
fi

echo "✅ Docker está instalado"
echo "✅ Docker Compose está instalado"
echo ""

# Verificar si el puerto 8080 está disponible
if lsof -Pi :8080 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "⚠️  Advertencia: El puerto 8080 está en uso"
    echo "Puedes cambiar el puerto en docker-compose.yml"
    echo ""
    read -p "¿Deseas continuar de todas formas? (s/n): " choice
    if [ "$choice" != "s" ] && [ "$choice" != "S" ]; then
        exit 0
    fi
fi

echo "🔨 Construyendo la imagen Docker..."
docker-compose build

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Imagen construida exitosamente"
    echo ""
    echo "======================================"
    echo "Para iniciar la aplicación, ejecuta:"
    echo "  docker-compose up"
    echo ""
    echo "Para iniciar en segundo plano:"
    echo "  docker-compose up -d"
    echo ""
    echo "Para detener la aplicación:"
    echo "  docker-compose down"
    echo ""
    echo "Credenciales de prueba:"
    echo "  Admin: admin / admin123"
    echo "  User:  user  / user123"
    echo "======================================"
else
    echo ""
    echo "❌ Error al construir la imagen"
    exit 1
fi