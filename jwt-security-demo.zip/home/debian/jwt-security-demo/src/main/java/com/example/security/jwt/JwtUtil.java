package com.example.security.jwt;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

/**
 * Clase utilitaria para generar, validar y extraer información de tokens JWT
 */
@Component
public class JwtUtil {

    @Value("${jwt.secret:MiClaveSecretaSuperSeguraParaFirmarTokensJWT2024DebeSerLargaYCompleja}")
    private String secret;

    @Value("${jwt.expiration:86400000}")
    private Long expiration;

    /**
     * Genera la clave secreta a partir del string configurado
     */
    private SecretKey getSigningKey() {
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Extrae el username del token
     */
    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    /**
     * Extrae la fecha de expiración del token
     */
    public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    /**
     * Extrae un claim específico del token
     */
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    /**
     * Extrae todos los claims del token
     * INTERNO: Parsea y valida la firma del token
     */
    private Claims extractAllClaims(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(getSigningKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (ExpiredJwtException e) {
            throw new RuntimeException("Token JWT ha expirado", e);
        } catch (UnsupportedJwtException e) {
            throw new RuntimeException("Token JWT no soportado", e);
        } catch (MalformedJwtException e) {
            throw new RuntimeException("Token JWT mal formado", e);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Token JWT vacío o nulo", e);
        }
    }

    /**
     * Verifica si el token ha expirado
     */
    private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    /**
     * Genera un token JWT para un usuario
     * PROCESO:
     * 1. Crea claims (payload del token)
     * 2. Define el subject (username)
     * 3. Establece fecha de emisión y expiración
     * 4. Firma el token con el algoritmo HS256
     */
    public String generateToken(org.springframework.security.core.userdetails.UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        
        // Agregar claims adicionales (roles, permisos, etc.)
        claims.put("authorities", userDetails.getAuthorities());
        
        return createToken(claims, userDetails.getUsername());
    }

    /**
     * Crea el token JWT con los claims y el subject
     */
    private String createToken(Map<String, Object> claims, String subject) {
        Date now = new Date();
        Date expiryDate = new Date(now.getTime() + expiration);

        return Jwts.builder()
                .claims(claims)
                .subject(subject)
                .issuedAt(now)
                .expiration(expiryDate)
                .signWith(getSigningKey())
                .compact();
    }

    /**
     * Valida el token JWT
     * PROCESO DE VALIDACIÓN:
     * 1. Extrae el username del token
     * 2. Verifica que coincida con el usuario actual
     * 3. Verifica que el token no haya expirado
     * 4. Verifica la firma del token (se hace automáticamente al extraer claims)
     */
    public Boolean validateToken(String token, org.springframework.security.core.userdetails.UserDetails userDetails) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
}