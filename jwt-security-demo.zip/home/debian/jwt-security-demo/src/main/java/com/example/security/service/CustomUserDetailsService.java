package com.example.security.service;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import jakarta.annotation.PostConstruct;
import java.util.*;

/**
 * Servicio personalizado para cargar usuarios
 * En producción, esto debería conectarse a una base de datos
 * 
 * SOLUCIÓN AL CICLO: Usamos @Lazy en el PasswordEncoder
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    private final PasswordEncoder passwordEncoder;

    // Simulación de una base de datos en memoria
    private Map<String, UserDetails> users = new HashMap<>();

    /**
     * Constructor que recibe PasswordEncoder
     * Ya no necesitamos @Lazy porque SecurityConfig ya no inyecta UserDetailsService
     */
    public CustomUserDetailsService(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Inicializar usuarios de prueba
     */
    @PostConstruct
    public void init() {
        // Usuario administrador
        users.put("admin", User.builder()
                .username("admin")
                .password(passwordEncoder.encode("admin123"))
                .authorities(
                    new SimpleGrantedAuthority("ROLE_ADMIN"),
                    new SimpleGrantedAuthority("ROLE_USER")
                )
                .build());

        // Usuario normal
        users.put("user", User.builder()
                .username("user")
                .password(passwordEncoder.encode("user123"))
                .authorities(new SimpleGrantedAuthority("ROLE_USER"))
                .build());

        System.out.println("=================================");
        System.out.println("Usuarios de prueba creados:");
        System.out.println("Usuario: admin | Contraseña: admin123");
        System.out.println("Usuario: user  | Contraseña: user123");
        System.out.println("=================================");
    }

    /**
     * Carga un usuario por su username
     * Este método es llamado por Spring Security durante la autenticación
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserDetails user = users.get(username);
        
        if (user == null) {
            throw new UsernameNotFoundException("Usuario no encontrado: " + username);
        }
        
        return user;
    }

    /**
     * Método auxiliar para obtener todos los usuarios (solo para demostración)
     */
    public Collection<UserDetails> getAllUsers() {
        return users.values();
    }
}