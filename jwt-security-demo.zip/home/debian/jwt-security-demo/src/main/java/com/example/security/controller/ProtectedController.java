package com.example.security.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * Controlador con endpoints protegidos que requieren JWT válido
 */
@RestController
@RequestMapping("/api/protected")
public class ProtectedController {

    /**
     * Endpoint protegido básico
     * Requiere autenticación con JWT válido
     */
    @GetMapping("/hello")
    public ResponseEntity<?> hello() {
        // Obtener información del usuario autenticado desde el SecurityContext
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "¡Hola! Has accedido a un endpoint protegido");
        response.put("username", authentication.getName());
        response.put("authorities", authentication.getAuthorities());
        
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint que solo puede ser accedido por usuarios con rol USER
     */
    @GetMapping("/user")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> userEndpoint() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Endpoint para usuarios con rol USER");
        response.put("username", authentication.getName());
        
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint que solo puede ser accedido por administradores
     */
    @GetMapping("/admin")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> adminEndpoint() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        Map<String, Object> response = new HashMap<>();
        response.put("message", "Endpoint exclusivo para ADMINISTRADORES");
        response.put("username", authentication.getName());
        response.put("warning", "Ten cuidado, este es un área sensible");
        
        return ResponseEntity.ok(response);
    }

    /**
     * Endpoint que retorna información del perfil del usuario autenticado
     */
    @GetMapping("/profile")
    public ResponseEntity<?> getProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        Map<String, Object> profile = new HashMap<>();
        profile.put("username", authentication.getName());
        profile.put("roles", authentication.getAuthorities());
        profile.put("authenticated", authentication.isAuthenticated());
        profile.put("details", authentication.getDetails());
        
        return ResponseEntity.ok(profile);
    }

    /**
     * Endpoint público para comparación (no requiere autenticación)
     */
    @GetMapping("/public/info")
    public ResponseEntity<?> publicInfo() {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Este es un endpoint público");
        response.put("note", "No requiere autenticación");
        
        return ResponseEntity.ok(response);
    }
}