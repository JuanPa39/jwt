package com.example.security.jwt;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Filtro que intercepta cada petición HTTP para validar el token JWT
 * FLUJO INTERNO:
 * 1. Extrae el token del header Authorization
 * 2. Valida el token JWT
 * 3. Carga los detalles del usuario
 * 4. Construye el contexto de seguridad (SecurityContext)
 * 5. Permite que la petición continúe
 */
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(
            HttpServletRequest request,
            HttpServletResponse response,
            FilterChain filterChain) throws ServletException, IOException {

        // 1. Extraer el header Authorization
        final String authorizationHeader = request.getHeader("Authorization");

        String username = null;
        String jwt = null;

        // 2. Verificar si el header contiene un Bearer token
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            jwt = authorizationHeader.substring(7); // Remover "Bearer " del inicio
            
            try {
                // 3. Extraer el username del token
                username = jwtUtil.extractUsername(jwt);
            } catch (Exception e) {
                logger.error("Error al extraer username del token JWT", e);
            }
        }

        // 4. Si hay username y no hay autenticación previa en el contexto
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            
            // 5. Cargar los detalles del usuario desde la base de datos
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(username);

            // 6. Validar el token
            if (jwtUtil.validateToken(jwt, userDetails)) {
                
                // 7. CONSTRUCCIÓN DEL CONTEXTO DE SEGURIDAD:
                // Crear un objeto de autenticación con los detalles del usuario
                UsernamePasswordAuthenticationToken authenticationToken = 
                    new UsernamePasswordAuthenticationToken(
                        userDetails, 
                        null, 
                        userDetails.getAuthorities()
                    );
                
                // Agregar detalles adicionales de la petición HTTP
                authenticationToken.setDetails(
                    new WebAuthenticationDetailsSource().buildDetails(request)
                );

                // 8. Establecer la autenticación en el SecurityContext
                // Esto permite que Spring Security sepa que el usuario está autenticado
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
                
                logger.debug("Usuario autenticado: " + username);
            }
        }

        // 9. Continuar con la cadena de filtros
        filterChain.doFilter(request, response);
    }
}