package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@SpringBootApplication
@EnableMethodSecurity(prePostEnabled = true)
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        
        System.out.println("\n" + "=".repeat(60));
        System.out.println("JWT Security Demo - Aplicación iniciada");
        System.out.println("Puerto: 8080");
        System.out.println("\nCredenciales de prueba:");
        System.out.println("  Admin: admin / admin123");
        System.out.println("  User:  user  / user123");
        System.out.println("\nEndpoints disponibles:");
        System.out.println("  POST /api/auth/login - Login y obtención de token");
        System.out.println("  GET  /api/auth/validate - Validar token");
        System.out.println("  GET  /api/protected/hello - Endpoint protegido");
        System.out.println("  GET  /api/protected/user - Solo rol USER");
        System.out.println("  GET  /api/protected/admin - Solo rol ADMIN");
        System.out.println("  GET  /api/protected/profile - Perfil del usuario");
        System.out.println("=".repeat(60) + "\n");
    }
}