package com.example.security.controller;

import com.example.security.jwt.JwtUtil;
import com.example.security.model.AuthRequest;
import com.example.security.model.AuthResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador para manejar el login y generación de tokens JWT
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * Endpoint de login que genera un token JWT
     * 
     * FLUJO:
     * 1. Recibe credenciales (username y password)
     * 2. Autentica al usuario con AuthenticationManager
     * 3. Si la autenticación es exitosa, carga los detalles del usuario
     * 4. Genera un token JWT
     * 5. Retorna el token al cliente
     * 
     * @param authRequest Objeto con username y password
     * @return AuthResponse con el token JWT
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthRequest authRequest) {
        try {
            // 1. Intentar autenticar al usuario
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                    authRequest.getUsername(),
                    authRequest.getPassword()
                )
            );

            // 2. Si la autenticación es exitosa, cargar los detalles del usuario
            final UserDetails userDetails = userDetailsService
                    .loadUserByUsername(authRequest.getUsername());

            // 3. Generar el token JWT
            final String jwt = jwtUtil.generateToken(userDetails);

            // 4. Retornar la respuesta con el token
            return ResponseEntity.ok(new AuthResponse(
                jwt,
                userDetails.getUsername(),
                userDetails.getAuthorities().toString()
            ));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(401)
                    .body("Credenciales incorrectas");
        } catch (Exception e) {
            return ResponseEntity.status(500)
                    .body("Error en el servidor: " + e.getMessage());
        }
    }

    /**
     * Endpoint para validar si un token es válido
     */
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String token) {
        try {
            String jwt = token.substring(7); // Remover "Bearer "
            String username = jwtUtil.extractUsername(jwt);
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);
            
            if (jwtUtil.validateToken(jwt, userDetails)) {
                return ResponseEntity.ok("Token válido para usuario: " + username);
            } else {
                return ResponseEntity.status(401).body("Token inválido");
            }
        } catch (Exception e) {
            return ResponseEntity.status(401).body("Token inválido: " + e.getMessage());
        }
    }
}